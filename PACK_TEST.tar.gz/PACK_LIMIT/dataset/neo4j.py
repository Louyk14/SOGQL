from py2neo import Graph, Node, Relationship
graph = Graph("bolt://localhost:7687", auth=('neo4j', '1996723lyk'))
tx = graph.begin()
id2node = dict()

lcount = 0
with open('human.graph', 'r') as f:
	lines = f.readlines()
	line = lines[0][:-1].split(' ')
	vertex_num = int(line[1])
	edge_num = int(line[2])

	for line in lines[1:]:
		lcount+= 1
		if lcount % 1000 == 0:
			print(lcount)
		line = line[:-1].split(' ')
		ltype = line[0]
		if ltype == 'v':
			vid = line[1]
			vlabel = line[2]
			newvertex = Node(vlabel, id=vid)
			tx.create(newvertex)
			id2node[vid] = newvertex
		elif ltype == 'e':
			srcid = line[1]
			dstid = line[2]
			rel = Relationship(id2node[srcid], id2node[dstid])
			tx.create(rel)

	tx.commit()