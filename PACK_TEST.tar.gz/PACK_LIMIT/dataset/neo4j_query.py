from py2neo import Graph, Node, Relationship
graph = Graph("bolt://localhost:7687", auth=('neo4j', '1996723lyk'))
import time

if __name__ == '__main__':
	input_data_graph_path = './dataset//'
    input_query_graph_path = './pattern//'

    # print(input_binary_path, input_data_graph_path, input_query_graph_folder_path)
    # check the correctness of Filtering.
    test_pair = []
    #real_set = ['yeast.graph']#, 'hprd.graph', 'human.graph']
    real_hprd_pattern = ['hprd//25s//', 'hprd//25d//', 'hprd//50s//', 'hprd//50d//', 'hprd//100s//', 'hprd//100d//', 'hprd//200s//', 'hprd//200d//']
    real_human_pattern = ['human//20s//', 'human//20d//', 'human//25s//', 'human//25d//']#['human//10s//', 'human//10d//', 'human//15s//', 'human//15d//', 'human//20s//', 'human//20d//', 'human//25s//', 'human//25d//']
    real_yeast_pattern = ['yeast//25s//', 'yeast//25d//', 'yeast//50s//', 'yeast//50d//', 'yeast//100s//', 'yeast//100d//', 'yeast//200s//', 'yeast//200d//']

    #for rset in ['hprd.graph']:
    #    for rpat in real_hprd_pattern:
    #        for i in range(0, 100):
    #            test_pair.append((rset, rpat + str(i) + '.graph'))

    #for rset in ['human.graph']:
    #    for rpat in real_human_pattern:
    #        for i in range(0, 100):
    #            test_pair.append((rset, rpat + str(i) + '.graph'))

    for rset in ['yeast.graph']:
        for rpat in real_yeast_pattern:
            for i in range(0, 100):
               test_pair.append((rset, rpat + str(i) + '.graph'))

    #test_pair = [('test.graph', 'p.graph')]
    for query_pair in test_pair:
        data_graph_path = input_data_graph_path + query_pair[0]
        query_graph_path = input_query_graph_path + query_pair[1]
        #print(query_graph_path, data_graph_path)
        
        with open(query_graph_path, 'r') as f:
        	string cypher = "MATCH "
        	vertex_list = ""
			lines = f.readlines()
			line = lines[0][:-1].split(' ')
			vertex_num = int(line[1])
			edge_num = int(line[2])
			id2node = dict()

			for line in lines[1:]:
				line = line[:-1].split(' ')
				ltype = line[0]
				if ltype == 'v':
					vid = line[1]
					vlabel = line[2]
					id2node[vid] = '(v' + vid + ' :`' + vlabel + '`)'
					vertex_list
				elif ltype == 'e':
					srcid = line[1]
					dstid = line[2]
					cypher = cypher + ' ' + id2node[srcid] + '--' + id2node[dstid] + ','

			cypher = cypher[:-1]
			#cypher = cyper + ' RETURN v0 ' + 'SKIP 99999 LIMIT 0;'
			cypher = cyper + ' RETURN COUNT(v0);'

			print(cypher)
			start - timeclock()
			embedding_num = graph.run(cypher).data()
			end = time.clock()
			time_cost = (end - start)
        
	        outputname = 'cypher_result//' + query_pair[1].split('//')[0] + '_' + query_pair[1].split('//')[1] + '.log'
	        with open(outputname, 'a') as f:
	            f.write(str(embedding_num) + ' ' + str(time_cost) + '\n')
