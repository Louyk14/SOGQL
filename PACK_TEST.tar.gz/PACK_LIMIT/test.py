import sys
import os
import glob
from subprocess import Popen, PIPE


def generate_args(binary, *params):
    arguments = [binary]
    arguments.extend(list(params))
    return arguments


def execute_binary(args):
    process = Popen(' '.join(args), shell=True, stdout=PIPE, stderr=PIPE)
    (std_output, std_error) = process.communicate()
    process.wait()
    rc = process.returncode

    return rc, std_output, std_error


if __name__ == '__main__':
    input_binary_path = 'GraphDBLanguage'

    dir_path = os.path.dirname(os.path.realpath(__file__)).replace('\\', '/')
    input_data_graph_path = './dataset//'
    input_query_graph_path = './pattern//'

    # print(input_binary_path, input_data_graph_path, input_query_graph_folder_path)
    # check the correctness of Filtering.
    test_pair = []
    #real_set = ['yeast.graph']#, 'hprd.graph', 'human.graph']
    #real_hprd_pattern = ['hprd//25s//', 'hprd//25d//', 'hprd//50s//', 'hprd//50d//', 'hprd//100s//', 'hprd//100d//', 'hprd//200s//', 'hprd//200d//']
    #real_human_pattern = ['human//10s//', 'human//10d//', 'human//15s//', 'human//15d//', 'human//20s//', 'human//20d//', 'human//25s//', 'human//25d//']
    #real_yeast_pattern = ['yeast//25s//', 'yeast//25d//', 'yeast//50s//', 'yeast//50d//', 'yeast//100s//', 'yeast//100d//', 'yeast//200s//', 'yeast//200d//']

    real_hprd_pattern = ['hprd//4//', 'hprd//8d//', 'hprd//8s//', 'hprd//16d//', 'hprd//16s//', 'hprd//24d//', 'hprd//24s//', 'hprd//32d//', 'hprd//32s//']
    real_human_pattern = ['human//4//', 'human//8d//', 'human//8s//', 'human//12d//', 'human//12s//', 'human//16d//', 'human//16s//', 'human//20d//', 'human//20s//']
    real_yeast_pattern =  ['yeast//4//', 'yeast//8d//', 'yeast//8s//', 'yeast//16d//', 'yeast//16s//', 'yeast//24d//', 'yeast//24s//', 'yeast//32d//', 'yeast//32s//']

    for rset in ['hprd.graph']:
        for rpat in real_hprd_pattern:
            for i in range(0, 100):
                test_pair.append((rset, rpat + str(i) + '.graph'))

    for rset in ['human.graph']:
        for rpat in real_human_pattern:
            for i in range(0, 100):
                test_pair.append((rset, rpat + str(i) + '.graph'))

    for rset in ['yeast.graph']:
        for rpat in real_yeast_pattern:
            for i in range(0, 100):
               test_pair.append((rset, rpat + str(i) + '.graph'))

    #test_pair = [('test.graph', 'p.graph')]
    for query_pair in test_pair:
        data_graph_path = input_data_graph_path + query_pair[0]
        query_graph_path = input_query_graph_path + query_pair[1]
        #print(query_graph_path, data_graph_path)
        execution_args = generate_args(input_binary_path, data_graph_path, query_graph_path)

        (rc, std_output, std_error) = execute_binary(execution_args)       
        #print(rc, std_output)
        query_graph_name = os.path.splitext(os.path.basename(query_graph_path))[0]
        embedding_num = 0
        time_cost = 0
        std_output_list = std_output.decode("utf-8").split('\n')[0].split(' ')
        #print(std_output_list)
        load_time_cost = std_output_list[0]
        embedding_num = std_output_list[1]
        total_time_cost = std_output_list[2]

        outputname = 'result_test//' + query_pair[1].split('//')[0] + '_' + query_pair[1].split('//')[1] + '.log'
        with open(outputname, 'a') as f:
            f.write(str(embedding_num) + ' ' + str(load_time_cost) + ' ' + str(total_time_cost) + '\n')

        #with open('test_result_.log', 'a') as f:
        #    f.write(query_pair[0] + ' ' + query_pair[1] + ' NUM: ' + str(embedding_num) + ' TIME: ' + str(time_cost) + '\n')
    
